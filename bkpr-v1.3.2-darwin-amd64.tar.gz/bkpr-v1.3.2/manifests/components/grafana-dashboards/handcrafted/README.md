# Grafana handcrafted dashboards

These dashboards have been hand crafted by the Bitnami SRE team.
All of them are ordered in subfolders depending the ambit of the dashboard.

Also, the `$datasource` variable has been configured in Grafana to allow multi-datasource setups.

All the dashboards that are present in this folder are meant to be migrated to _jsonnet_ in the near future.